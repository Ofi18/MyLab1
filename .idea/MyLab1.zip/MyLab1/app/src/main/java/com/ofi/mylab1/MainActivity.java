package com.ofi.mylab1;

import android.content.DialogInterface;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    //  Declare member variables here:

    TextView mNumberStrike;
    TextView mNumberBall;
    Button bStrike;
    Button bBall;
    private int strikeIndex=0 ;
    private int ballIndex=0;
    private String outMessage = "Out!";
    private String walkMessage = "Walk!";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //bStrike function Declaration
        bStrike = (Button) findViewById(R.id.button);
        bStrike.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                strike_action();
            }
        });


        //bBall function Declaration
        bBall = (Button) findViewById(R.id.button2);
        bBall.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ball_action();
            }
        });
    }

    //strike_action function
    private void strike_action() {
        strikeIndex++;
        update_strike();
        if (strikeIndex == 3) {
            alertFunction(outMessage);
        }
    }
    //ball_action function
    private void ball_action() {
        ballIndex++;
        update_ball();
        if (ballIndex == 4) {
            alertFunction(walkMessage);
        }
    }

    //update_ball function
    private void update_ball() {
        mNumberBall = (TextView) findViewById(R.id.textView5);
        mNumberBall.setText(Integer.toString(ballIndex));
    }

    //update_strike function
    private void update_strike() {
        mNumberStrike = (TextView) findViewById(R.id.textView3);
        mNumberStrike.setText(Integer.toString(strikeIndex));

    }

    //rest_count function
    private void rest_count() {
        strikeIndex = 0;
        ballIndex = 0;
        update_strike();
        update_ball();
    }

    //alertFunction function
    private void alertFunction(String message) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setMessage(message);
        builder.setCancelable(false);
        builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {
                rest_count();
            }
        });
        builder.show();
    }


}



















